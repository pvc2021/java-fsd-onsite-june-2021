package com.pradeep.cms.presnetation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;

import com.pradeep.cms.config.CmsAppConfing;
import com.pradeep.cms.domain.Customer;
import com.pradeep.cms.service.CustomerService;

@Controller
//@Component  //default id customerMainApp
public class CustomerMainApp {

	@Autowired
//dependency	
	private CustomerService cs;

	public CustomerMainApp() {
		System.out.println("==========CustomerMainApp created=========");
	}

	public void addCustomer(Customer customer) {

		if (cs.saveCustomer(customer))
			System.out.println("Customer with Id [" + customer.getCustomerId() + "] created cusscessfully");
		else
			System.out.println("Problem In adding the customer");
	}

	public void updateCustomer(Customer customer) {

		if (cs.updateCustomer(customer))
			System.out.println("Customer with Id [" + customer.getCustomerId() + "] updated cusscessfully");
		else
			System.out.println("Customer Id doesn't exist");
	}

	public void deleteCustomer(int customerId) {

		if (cs.deleteCustomer(customerId))
			System.out.println("Customer with Id [" + customerId + "] deleted cusscessfully");
		else
			System.out.println("Customer Id doesn't exist");
	}

	public void findCustomer(int customerId) {

		Customer customer = cs.findCustomerById(customerId);

		if (customer != null)
			System.out.println("Customer with Id [" + customerId + "] details  \n\n" + customer);
		else
			System.out.println("Customer Id doesn't exist");
	}

	public void init() {
		System.out.println("=====CustomerMainApp initailized=====");
	}

	public void destroy() {
		System.out.println("=====CustomerMainApp destroyed=====");
	}

	public void showAllCustomers() {

		System.out.println("Customer Details\n=========================================");

		for (Customer c : cs.findAllCustomers())
			System.out.println(c);
	}

	public static void main(String[] args) {

//Create a Advanced Spring Container	

		AnnotationConfigApplicationContext c = new AnnotationConfigApplicationContext(CmsAppConfing.class);

		System.out.println("==========Spring Advanced Container created===========");

		CustomerMainApp cma = (CustomerMainApp) c.getBean("customerMainApp");

		cma.showAllCustomers();

		// shutdown the container
		c.registerShutdownHook();

	}

}
