package com.pradeep.cms.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@ComponentScan(basePackages = {"com.pradeep"})
@Configuration  //by default It will scan only current package in which it is defined
public class CmsAppConfing {

	public CmsAppConfing() {
	System.out.println("===CmsAppConfing created====");
	}
}
