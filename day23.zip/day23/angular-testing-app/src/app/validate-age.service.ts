import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ValidateAgeService {

  constructor() { }


  validate(age:number):boolean{
    return age>=20 && age<=60;
  }

}
