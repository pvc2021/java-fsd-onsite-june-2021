import { TestBed } from '@angular/core/testing';

import { ValidateAgeService } from './validate-age.service';

xdescribe('ValidateAgeService', () => {
  let service: ValidateAgeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ValidateAgeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return true for lower boundry value 20', () => {
    expect(service.validate(20)).toEqual(true);
  });

it('should return true for upper boundry value 60', () => {
    expect(service.validate(60)).toEqual(true);
  });

  it('should return true for witin range   56', () => {
    expect(service.validate(56)).toEqual(true);
  });
  
  it('should return false for value 15 less than lower boundry value 20', () => {
    expect(service.validate(15)).toEqual(false);
  });
  
  it('should return false for value 67 greater than upper boundry value 60', () => {
    expect(service.validate(67)).toEqual(false);
  });
   

});
