import { Directive, ElementRef, Input, Renderer2 } from '@angular/core';

@Directive({
  selector: '[bgColor]'
})
export class BgColorDirective {

  
  constructor(private e:ElementRef,private r:Renderer2) {
    console.log("$$$$$$$$$$$$$$$$$$ BgColorDirective created   $$$$$$$$$$")
   }

  ngOnInit() {
    console.log("$$$$$$$$$$$$$$$$$$ BgColorDirective initialized   $$$$$$$$$$")
  }
  
  ngOnDestroy() {
    console.log("$$$$$$$$$$$$$$$$$$ BgColorDirective destroyed  $$$$$$$$$$")
   
  }
 
  
  //work only if Compone have @Input() property 
  ngOnChanges() {
    console.log("$$$$$$$$$$$$$$$$$$ BgColorDirective ngOnChanges  $$$$$$$$$$")
  }
  
  ngAfterContentInit() {
    console.log("$$$$$$$$$$$$$$$$$$ BgColorDirective ngAfterContentInit  $$$$$$$$$$")
  }
  
  ngAfterContentChecked() {
    console.log("$$$$$$$$$$$$$$$$$$ BgColorDirective ngAfterContentChecked  $$$$$$$$$$")
  }
  
  ngAfterViewChecked() {
    console.log("$$$$$$$$$$$$$$$$$$ BgColorDirective ngAfterViewChecked  $$$$$$$$$$")
  }
  
  ngAfterViewInit() {
    console.log("$$$$$$$$$$$$$$$$$$ BgColorDirective ngAfterViewInit  $$$$$$$$$$")
  }
  

@Input()  
set bgColor(value:string){
  console.log("In setBgColor :"+value);
   this.r.setStyle(this.e.nativeElement,"background-color",value);
}

}
