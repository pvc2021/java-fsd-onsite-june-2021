import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[show]'
})
export class ShowDirective {

  constructor(private t:TemplateRef<any>,private vcr:ViewContainerRef) {
    console.log("$$$$$$$$$$$$$$$$$$ ShowDirective created   $$$$$$$$$$")
  }

 ngOnInit() {
   console.log("$$$$$$$$$$$$$$$$$$ ShowDirective initialized   $$$$$$$$$$")
 }
 
 ngOnDestroy() {
   console.log("$$$$$$$$$$$$$$$$$$ ShowDirective destroyed  $$$$$$$$$$")
  
 }

 
 //work only if Compone have @Input() property 
 ngOnChanges() {
   console.log("$$$$$$$$$$$$$$$$$$ ShowDirective ngOnChanges  $$$$$$$$$$")
 }
 
 ngAfterContentInit() {
   console.log("$$$$$$$$$$$$$$$$$$ ShowDirective ngAfterContentInit  $$$$$$$$$$")
 }
 
 ngAfterContentChecked() {
   console.log("$$$$$$$$$$$$$$$$$$ ShowDirective ngAfterContentChecked  $$$$$$$$$$")
 }
 
 ngAfterViewChecked() {
   console.log("$$$$$$$$$$$$$$$$$$ ShowDirective ngAfterViewChecked  $$$$$$$$$$")
 }
 
 ngAfterViewInit() {
   console.log("$$$$$$$$$$$$$$$$$$ ShowDirective ngAfterViewInit  $$$$$$$$$$")
 }

@Input()
set show(value:boolean){
   console.log("====In setShow  "+value);
   if(value)
   this.vcr.createEmbeddedView(this.t)
   else
   this.vcr.clear();
 
  }



}
