import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'gender1'
})
export class Gender1Pipe implements PipeTransform {

  transform(value: number): string {
    switch(value){
      case 1: return "Mr.";
      case 2: return "Ms.";
      case 3: return "Master.";
     
    }
    
    return "";

  }

}
