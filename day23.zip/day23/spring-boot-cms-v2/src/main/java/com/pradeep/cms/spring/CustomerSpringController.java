package com.pradeep.cms.spring;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.pradeep.cms.domain.Customer;
import com.pradeep.cms.service.CustomerService;


@RequestMapping("/spring")
@Controller
//@Component("customerMainApp")
public class CustomerSpringController {

	@Qualifier("mySQLCustomerServiceImpl")
	@Autowired
	private CustomerService customerService;

	public CustomerSpringController() {
		System.out.println("=============CustomerSpringController  created=============");
	}

	@PostMapping("/add")
	public String addCustomer(@ModelAttribute("customer") Customer customer, ModelMap map) {

		customerService.saveCustomer(customer);

		map.addAttribute("customers", customerService.findAllCustomers());
		return "customerList";
	}

	
	

	@PostMapping("/update")
	public String updateCustomer(@ModelAttribute("customer")Customer customer, ModelMap map) {

		customerService.updateCustomer(customer);

		map.addAttribute("customers", customerService.findAllCustomers());
		return "customerList";
	}
	@GetMapping("/new")
	public String newCustomer(ModelMap map) {

		map.addAttribute("customer", new Customer());

		map.addAttribute("customers", customerService.findAllCustomers());

		return "addCustomer";
	}

	
	
	@RequestMapping("/edit/{id}")
	public String newCustomer(@PathVariable("id")int customerId,ModelMap map) {

		map.addAttribute("customer", customerService.findCustomer(customerId));

		map.addAttribute("customers", customerService.findAllCustomers());

		return "editCustomer";
	}

	
	@GetMapping("/delete")
	public String deleteCustomer( @RequestParam("customerId") int customerId,ModelMap map) {
		
		customerService.deleteCustomer(customerId);
		
		map.addAttribute("customers", customerService.findAllCustomers());

		return "customerList";
		
		
		
	}

	public void showCustomer(int customerId) {

		Customer customer = customerService.findCustomer(customerId);

		if (customer != null)
			System.out.println("Customer with id [" + customerId + "] Details \n\n" + customer);
		else
			System.out.println("Customer not found");
	}

	@GetMapping("/customers")
	public String getAllCustomers(ModelMap map) {

		map.addAttribute("customers", customerService.findAllCustomers());

		return "customerList";
	}

	@PostConstruct
	public void init() {
		System.out.println("================CustomerMainApp  initialized============");
	}

	@PreDestroy
	public void destroy() {
		System.out.println("================CustomerMainApp  destroyed============");
	}

}
