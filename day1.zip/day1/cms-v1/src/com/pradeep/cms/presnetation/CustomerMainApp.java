package com.pradeep.cms.presnetation;

import com.pradeep.cms.dao.MapCustomerDaoImpl;
import com.pradeep.cms.domain.Customer;
import com.pradeep.cms.service.CustomerService;
import com.pradeep.cms.service.MapCustomerServiceImpl;

public class CustomerMainApp {

//dependency	
private CustomerService customerService;	
	

public CustomerMainApp() {
	System.out.println("==========CustomerMainApp created=========");
}

//constructor injection
public CustomerMainApp(CustomerService customerService) {
	super();
	this.customerService = customerService;
	System.out.println("==========CustomerMainApp param constructor=========");

}

//setter injection
public void setCustomerService(CustomerService customerService) {
	this.customerService = customerService;
	System.out.println("==========CustomerMainApp setCustomerService=========");
}


public void addCustomer(Customer customer) {
	
	if(customerService.saveCustomer(customer))
		System.out.println("Customer with Id ["+customer.getCustomerId()+"] created cusscessfully");
	else
		System.out.println("Problem In adding the customer");
}

public void updateCustomer(Customer customer) {
	
	if(customerService.updateCustomer(customer))
		System.out.println("Customer with Id ["+customer.getCustomerId()+"] updated cusscessfully");
	else
		System.out.println("Customer Id doesn't exist");
}

public void deleteCustomer(int customerId) {
	
	if(customerService.deleteCustomer(customerId))
		System.out.println("Customer with Id ["+customerId+"] deleted cusscessfully");
	else
		System.out.println("Customer Id doesn't exist");
}


public void findCustomer(int customerId) {
	
	Customer customer=customerService.findCustomerById(customerId);
	
	
	if(customer!=null)
		System.out.println("Customer with Id ["+customerId+"] details  \n\n"+customer);
	else
		System.out.println("Customer Id doesn't exist");
}


public void showAllCustomers() {
	
		System.out.println("Customer Details\n=========================================");
	
		for(Customer c:customerService.findAllCustomers())
			System.out.println(c);
}


public static void main(String[] args) {
	MapCustomerDaoImpl mcdi=new MapCustomerDaoImpl();
	
	MapCustomerServiceImpl mcsi=new MapCustomerServiceImpl(mcdi); //constructor injection
		
	CustomerMainApp cma=new CustomerMainApp(mcsi); //constructor injection
	
		
	//mcsi.setCustomerDao(mcdi); //setter
	
    //cma.setCustomerService(mcsi);  //setter
	
	cma.showAllCustomers();
	
	
}

	
}
