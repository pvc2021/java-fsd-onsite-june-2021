package com.pradeep.cms.service;

import java.util.Collection;

import com.pradeep.cms.dao.CustomerDao;
import com.pradeep.cms.domain.Customer;

public class MapCustomerServiceImpl implements CustomerService{
	
	//dependency
	private CustomerDao customerDao;
	
	public MapCustomerServiceImpl() {
	System.out.println("=====MapCustomerServiceImpl created=======");
	
	}
	
	
	
    //constructor injection
	public MapCustomerServiceImpl(CustomerDao customerDao) {
		super();
		this.customerDao = customerDao;
		System.out.println("=====MapCustomerServiceImpl param cosntructor======");
	}


	//setter injection
	public void setCustomerDao(CustomerDao customerDao) {
		this.customerDao = customerDao;
		System.out.println("=====MapCustomerServiceImpl setCustomerDao=======");
	}

	@Override
	public boolean saveCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return customerDao.saveCustomer(customer);
	}

	@Override
	public boolean updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return customerDao.updateCustomer(customer);
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		// TODO Auto-generated method stub
		return customerDao.deleteCustomer(customerId);
	}

	@Override
	public Customer findCustomerById(int customerId) {
		// TODO Auto-generated method stub
		return customerDao.findCustomerById(customerId);
	}

	@Override
	public Collection<Customer> findAllCustomers() {
		// TODO Auto-generated method stub
		return customerDao.findAllCustomers();
	}

}
