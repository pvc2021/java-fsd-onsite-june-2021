import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { HomeComponent } from './home/home.component';
import { TechnologiesComponent } from './technologies/technologies.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { UsersComponent } from './users/users.component';
import { PostsComponent } from './posts/posts.component';
import { TodosComponent } from './todos/todos.component';
import { CommentsComponent } from './comments/comments.component';
import { AlbumsComponent } from './albums/albums.component';
import { PhotosComponent } from './photos/photos.component';
import { UsersListComponent } from './users-list/users-list.component';
import { UsersTableComponent } from './users-table/users-table.component';
import { CaseStudyComponent } from './case-study/case-study.component';
import {HttpClientModule} from '@angular/common/http'
@NgModule({
  declarations: [ //components,directive,pipes
    AppComponent, AngularBasicsComponent, HomeComponent, TechnologiesComponent, AngularPipesComponent, UsersComponent, PostsComponent, TodosComponent, CommentsComponent, AlbumsComponent, PhotosComponent, UsersListComponent, UsersTableComponent, CaseStudyComponent
  ],
  imports: [ //modules
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [], //service

  //bootstrap: [AppComponent,AngularBasicsComponent,HomeComponent,TechnologiesComponent,AngularPipesComponent]  //components
  bootstrap: [AppComponent]  //components

})
export class AppModule { }
