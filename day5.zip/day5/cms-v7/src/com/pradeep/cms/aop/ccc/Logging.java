package com.pradeep.cms.aop.ccc;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import com.pradeep.cms.domain.Customer;

@Aspect
@Component
public class Logging {

	public Logging() {
		System.out.println("Logging Advice created.....");
	}

	@Pointcut("execution(* com.pradeep.cms.service.CustomerService.*(..))")
	private void selectAll() {
	}

	@Pointcut("execution(* com.pradeep.cms.service.CustomerService.findCustomerById(..))")
	private void select() {
	}

	/**
	 * * This is the method which I would like to execute * before a selected method
	 * execution.
	 */

	@Before("selectAll()")
	public void beforeAdvice() {
		System.err.println("Going to setup customer profile.");
	}

	/**
	 * * This is the method which I would like to execute * after a selected method
	 * execution.
	 */
	@After("selectAll()")
	public void afterAdvice() {
		System.err.println("Customer profile has been setup.");
	}

	/**
	 * * This is the method which I would like to execute * when any method returns.
	 */
	@AfterReturning(value = "selectAll()", returning = "retVal")
	public void afterReturningAdvice(Object retVal) {
		System.err.println("Customer afterReturning:" + retVal);
	}

	/**
	 * * This is the method which I would like to execute * if there is an exception
	 * raised by any method.
	 */
	@AfterThrowing(value = "selectAll()", throwing = "ex")
	public void AfterThrowingAdvice(Exception ex) {
		System.err.println("Customer There has been an exception: " + ex);
	}

	@Around("select()")
	public Object aroundAdvice(ProceedingJoinPoint joinPoint) throws Throwable {

		Object returnVal = null;

		System.err.println("In around Advice .....");

		try {
			System.err.println("Before Proceed :");
			returnVal = joinPoint.proceed();
			System.err.println("After  Proceed :" + returnVal);
			Customer value = (Customer) returnVal;

			value.setName(value.getName().toUpperCase());

		} catch (Throwable e) {
			e.printStackTrace();
		
			System.out.println("around Advice  exception wrapped.....");

		}
		System.out.println("around Advice  over.....");
		return returnVal;
	}

}
