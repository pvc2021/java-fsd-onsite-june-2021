import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  message="Hi Students";

  @Input()
  parentMessage="";


  @Output()
  childChanged=new EventEmitter<string>();  //custom event


  constructor() { }

  ngOnInit(): void {
  }



  sendMessageToParent(){
    console.log("In sendMessageToParent" +this.message);
    this.childChanged.emit(this.message);
  }



}
