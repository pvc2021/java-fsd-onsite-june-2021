import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomersService {

private baseURL="http://localhost:1212/spring-boot-cms-v2/rest/customers";

  constructor(private http:HttpClient) {
    console.log("========CustomersService created===============");
   
  }

  getAllCustomers():Observable<any>{
    return this.http.get(this.baseURL);
  }

  getCustomerById(customerId:number):Observable<any>{
    return this.http.get(this.baseURL+"/"+customerId);
  }

  deleteCustomerById(customerId:number):Observable<any>{
    return this.http.delete(this.baseURL+"/"+customerId);
  }

  updateCustomerById(customerId:number,customer:any):Observable<any>{
    return this.http.put(this.baseURL+"/"+customerId,customer);
  }
  
  addCustomer(customer:any):Observable<any>{
    return this.http.post(this.baseURL,customer);
  }
  
}
