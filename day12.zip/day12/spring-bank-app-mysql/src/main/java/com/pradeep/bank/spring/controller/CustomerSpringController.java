package com.pradeep.bank.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.pradeep.bank.model.Customer;
import com.pradeep.bank.service.CustomerService;

@Controller
@RequestMapping("/spring")
public class CustomerSpringController {

	@Autowired
	private CustomerService cs;

	public CustomerSpringController() {
		System.out.println("------------CustomerSpringController created -------------");
	}

	@RequestMapping("/getallcustomers")
	public String getAllCustomers(ModelMap map) {

		map.addAttribute("customers", cs.findAllCustomers());

		return "customerList";
	}

	@RequestMapping("/delete")
	public String deleteCustomer(@RequestParam("customerId") int customerId, ModelMap map) {
		cs.deleteCustomer(customerId);
		map.addAttribute("customers", cs.findAllCustomers());

		return "customerList";
	}

	@RequestMapping("/edit/{customerId}")
	public String editCustomer(@PathVariable("customerId") int customerId, ModelMap map) {

		map.addAttribute("customers", cs.findAllCustomers());
		map.addAttribute("customer", cs.findCustomer(customerId));

		return "editCustomer";
	}
	
	
	@RequestMapping("/new")
	public String newCustomer( ModelMap map) {

		map.addAttribute("customers", cs.findAllCustomers());
		map.addAttribute("customer", new Customer());

		return "addCustomer";
	}
	

	
	
	@RequestMapping(value="/update",method = RequestMethod.POST)
	public String updateCustomer(@ModelAttribute("customer") Customer customer, ModelMap map) {

		cs.updateCustomer(customer);

		map.addAttribute("customers", cs.findAllCustomers());

		return "customerList";
	}

	
	@RequestMapping(value="/add",method = RequestMethod.POST)
	public String addCustomer(@ModelAttribute("customer") Customer customer, ModelMap map) {

		cs.saveCustomer(customer);

		map.addAttribute("customers", cs.findAllCustomers());

		return "customerList";
	}

	
	
}
