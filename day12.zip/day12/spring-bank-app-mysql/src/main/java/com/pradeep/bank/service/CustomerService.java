package com.pradeep.bank.service;

import java.util.List;

import com.pradeep.bank.model.Customer;

public interface CustomerService {
	boolean  saveCustomer(Customer customer);
	boolean  updateCustomer(Customer customer);
	boolean  deleteCustomer(int customerId);
	List<Customer> findAllCustomers();
	Customer   findCustomer(int customerId);
		
}
