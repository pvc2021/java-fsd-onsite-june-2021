package com.pradeep.bank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pradeep.bank.dao.AccountDao;
import com.pradeep.bank.model.Account;

@Transactional
@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	private AccountDao accountDao;

	public AccountServiceImpl() {
		System.out.println("AccountService default constructor created.....");
	}

	@Override
	public boolean addAccount(Account account) {
		// TODO Auto-generated method stub
		return accountDao.save(account) == account;
	}

	@Override
	public boolean deleteAccount(int accno) {

		if (accountDao.existsById(accno)) {
			accountDao.deleteById(accno);
			return true;
		}
		return false;
	}

	@Override
	public boolean updateAccount(Account account) {

		if (accountDao.existsById(account.getAccno())) {
			return accountDao.save(account) == account;
		}
		return false;

	}

	@Transactional(readOnly = true)
	@Override
	public Account getAccount(int accno) {
		// TODO Auto-generated method stub
		return accountDao.findById(accno).get();

	}

	@Transactional(readOnly = true, timeout = 6)
	@Override
	public List<Account> getAllAccounts() {

		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// TODO Auto-generated method stub
		return accountDao.findAll();
	}

	@Override
	public boolean withdraw(int accno, double amount) {
System.out.println("In withdraw");
		Account account = accountDao.getOne(accno);

		account.setBalance(account.getBalance() - amount);

		return accountDao.save(account) == account;

	}

	@Override
	public boolean deposit(int accno, double amount) {
		
		System.out.println("In deposit");
		Account account = accountDao.getOne(accno);

		account.setBalance(account.getBalance() + amount);

		return accountDao.save(account) == account;
	}

	@Override
	public boolean fundTransfer(int source, int destination, double amount) {

		System.out.println("In service  :" + source + "   " + destination);
		withdraw(source, amount);
		//int a = 100 / 0;
		deposit(destination, amount);
		return true;
	}

}
