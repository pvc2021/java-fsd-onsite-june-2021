package com.pradeep.cms.service;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.pradeep.cms.dao.CustomerDao;
import com.pradeep.cms.dao.CustomerRepository;
import com.pradeep.cms.domain.Customer;
import com.pradeep.cms.rest.CustomerRestController;

@Service
public class MySQLCustomerServiceImpl implements CustomerService {

	@Autowired
	// dependency
	private CustomerRepository repository;

	public MySQLCustomerServiceImpl() {
		System.out.println("=====MySQLCustomerServiceImpl created=======");

	}

	@Override
	public boolean saveCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return repository.save(customer) == customer;
	}

	@Override
	public boolean updateCustomer(Customer customer) {

		if (repository.existsById(customer.getCustomerId()))
			return repository.save(customer) == customer;

		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		if (repository.existsById(customerId)) {
			repository.deleteById(customerId);
			return true;
		}
		return false;
	}

	@Override
	public Customer findCustomerById(int customerId) {
		// TODO Auto-generated method stub
		return repository.findById(customerId).get();
	}

	@Override
	public Collection<Customer> findAllCustomers() {
			
		return repository.findAll();
	}

}
