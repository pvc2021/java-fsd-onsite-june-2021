package com;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class Demo {
public static void main(String[] args) {
	
	BCryptPasswordEncoder bc=new BCryptPasswordEncoder();
	
	System.out.println("RAM     "+bc.encode("RAM"));
	System.out.println("RAHIM   "+bc.encode("RAHIM"));
	System.out.println("DAVID   "+bc.encode("DAVID"));
		
	
}
}
