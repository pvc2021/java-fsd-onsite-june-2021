package com.pradeep.cms.presnetation;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

import com.pradeep.cms.domain.Customer;
import com.pradeep.cms.service.CustomerService;

public class CustomerMainApp {

//dependency	
private CustomerService customerService;	
	

public CustomerMainApp() {
	System.out.println("==========CustomerMainApp created=========");
}

//constructor injection
public CustomerMainApp(CustomerService customerService) {
	super();
	this.customerService = customerService;
	System.out.println("==========CustomerMainApp param constructor=========");

}

//setter injection
public void setCustomerService(CustomerService customerService) {
	this.customerService = customerService;
	System.out.println("==========CustomerMainApp setCustomerService=========");
}


public void addCustomer(Customer customer) {
	
	if(customerService.saveCustomer(customer))
		System.out.println("Customer with Id ["+customer.getCustomerId()+"] created cusscessfully");
	else
		System.out.println("Problem In adding the customer");
}

public void updateCustomer(Customer customer) {
	
	if(customerService.updateCustomer(customer))
		System.out.println("Customer with Id ["+customer.getCustomerId()+"] updated cusscessfully");
	else
		System.out.println("Customer Id doesn't exist");
}

public void deleteCustomer(int customerId) {
	
	if(customerService.deleteCustomer(customerId))
		System.out.println("Customer with Id ["+customerId+"] deleted cusscessfully");
	else
		System.out.println("Customer Id doesn't exist");
}


public void findCustomer(int customerId) {
	
	Customer customer=customerService.findCustomerById(customerId);
	
	
	if(customer!=null)
		System.out.println("Customer with Id ["+customerId+"] details  \n\n"+customer);
	else
		System.out.println("Customer Id doesn't exist");
}


public void init() {
	System.out.println("=====CustomerMainApp initailized=====");
}

public void destroy() {
	System.out.println("=====CustomerMainApp destroyed=====");
}


public void showAllCustomers() {
	
		System.out.println("Customer Details\n=========================================");
	
		for(Customer c:customerService.findAllCustomers())
			System.out.println(c);
}


public static void main(String[] args) {
	
	
//create a Spring Core Container
	
//	XmlBeanFactory c=new XmlBeanFactory(new ClassPathResource("beans.xml"));
//	System.out.println("==========Spring Core Container created===========");
	
//Create a Advanced Spring Container	
	ClassPathXmlApplicationContext c=new ClassPathXmlApplicationContext("beans.xml");
	System.out.println("==========Spring Advanced Container created===========");

	//make a request to spring container
   // CustomerMainApp cma=c.getBean(CustomerMainApp.class);
	               
	CustomerMainApp cma=(CustomerMainApp)c.getBean("customerMainApp");
	CustomerMainApp cma1=(CustomerMainApp)c.getBean("customerMainApp");
	CustomerMainApp cma2=(CustomerMainApp)c.getBean("customerMainApp");
	   
	
	System.out.println(cma);
	System.out.println(cma1);
	System.out.println(cma2);
	
   
    
   cma.showAllCustomers();
  
   //shutdown the container
    c.registerShutdownHook();
   
   
}
	
}
