import { Component, OnDestroy, OnInit } from '@angular/core';
import { Observable, Subscriber } from 'rxjs';

@Component({
  selector: 'app-angular-basics', //where to inject
  templateUrl: './angular-basics.component.html', //where to display
  styleUrls: ['./angular-basics.component.css'] //how to display
})
export class AngularBasicsComponent implements OnInit ,OnDestroy {

 title="Angular 12 Basics";  //string

 colors=['RED','GREEN','BLUE']; //array

 day=1;//number
 min:number=1; //number
 max=8; // number
 


 show=true;//boolean
 hide:boolean=false; //boolean

 employee={'id':101,
          'name':'Pradeep chinchole',
          'salary':23459.453336333,
          'variable':0.15,
          'mobile':'9156252421',
          'pan':'amdpv8765d',
          'doj':new Date()}; //object
 


          showHide(){
            this.hide=!this.hide;
          }



time=new Observable<string>((s:Subscriber<string>)=>{
  
  setInterval(()=>{
    s.next(new Date().toLocaleString());
    },1000);
});






  constructor() { 
    console.log("===========AngularBasicsComponent created==============");

    
  }

  ngOnInit(): void {
    console.log("===========AngularBasicsComponent initialized==============");
    
  }

  ngOnDestroy(): void {
    console.log("===========AngularBasicsComponent destroyed==============");
    
  }

}
