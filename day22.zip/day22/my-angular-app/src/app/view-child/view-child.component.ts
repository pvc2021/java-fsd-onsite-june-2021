import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FgColorDirective } from '../directives/fg-color.directive';
import { NumberComponent } from '../number/number.component';

@Component({
  selector: 'app-view-child',
  templateUrl: './view-child.component.html',
  styleUrls: ['./view-child.component.css']
})
export class ViewChildComponent implements OnInit {

@ViewChild(NumberComponent,{static:false}) 
private n:NumberComponent;

@ViewChild(FgColorDirective,{static:false}) 
private f:FgColorDirective;


@ViewChild("name",{static:false}) 
private name:ElementRef;

@ViewChild("city",{static:false}) 
private city:ElementRef;

  constructor() { }

  ngOnInit(): void {
  }


  increase(){
    this.n.increment();
  }
  decrease(){
    this.n.decrement();
  }



  changeColor(){
    this.f.fgColor="green";
  }



  changeColors(){

    this.name.nativeElement.style.color="RED";
    this.name.nativeElement.style.backgroundColor="CYAN";
    
    this.city.nativeElement.style.color="brown";
    this.city.nativeElement.style.backgroundColor="yellow";

  }
}
