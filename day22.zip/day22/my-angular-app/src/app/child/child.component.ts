import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  message="Hi Students";

  @Input()
  parentMessage="";


  @Output()
  childChanged=new EventEmitter<string>();  //custom event


  constructor() {
    console.log("$$$$$$$$$$$$$$$$$$ ChildComponent created   $$$$$$$$$$")
   }

  ngOnInit() {
    console.log("$$$$$$$$$$$$$$$$$$ ChildComponent initialized   $$$$$$$$$$")
  }
  
  ngOnDestroy() {
    console.log("$$$$$$$$$$$$$$$$$$ ChildComponent destroyed  $$$$$$$$$$")
   
  }
  
  ngOnChanges() {
    console.log("$$$$$$$$$$$$$$$$$$ ChildComponent ngOnChanges  $$$$$$$$$$")
  }
  
  ngAfterContentInit() {
    console.log("$$$$$$$$$$$$$$$$$$ ChildComponent ngAfterContentInit  $$$$$$$$$$")
  }
  
  ngAfterContentChecked() {
    console.log("$$$$$$$$$$$$$$$$$$ ChildComponent ngAfterContentChecked  $$$$$$$$$$")
  }
  
  ngAfterViewChecked() {
    console.log("$$$$$$$$$$$$$$$$$$ ChildComponent ngAfterViewChecked  $$$$$$$$$$")
  }
  
  ngAfterViewInit() {
    console.log("$$$$$$$$$$$$$$$$$$ ChildComponent ngAfterViewInit  $$$$$$$$$$")
  }



  sendMessageToParent(){
    console.log("In sendMessageToParent" +this.message);
    this.childChanged.emit(this.message);
  }



}
