import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { HomeComponent } from './home/home.component';
import { TechnologiesComponent } from './technologies/technologies.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';

@NgModule({
  declarations: [ //components,directive,pipes
    AppComponent, AngularBasicsComponent, HomeComponent, TechnologiesComponent, AngularPipesComponent
  ],
  imports: [ //modules
    BrowserModule,
    AppRoutingModule
  ],
  providers: [], //service

  //bootstrap: [AppComponent,AngularBasicsComponent,HomeComponent,TechnologiesComponent,AngularPipesComponent]  //components
  bootstrap: [AppComponent]  //components

})
export class AppModule { }
