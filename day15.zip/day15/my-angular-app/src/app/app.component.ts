import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html', //where to display  if code is greater than 3 lines
  //template:'<b> <i> {{title}} </i> </b>', //if code is leass than 4 lines
  styleUrls: ['./app.component.css'] //how to display 
})
export class AppComponent {
 
  title = 'my-angular-app'; //string  //What to display
  count=100; //number   //what to display

}
