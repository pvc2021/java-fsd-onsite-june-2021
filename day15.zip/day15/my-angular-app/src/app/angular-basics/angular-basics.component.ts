import { Component, OnDestroy, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-basics', //where to inject
  templateUrl: './angular-basics.component.html', //where to display
  styleUrls: ['./angular-basics.component.css'] //how to display
})
export class AngularBasicsComponent implements OnInit ,OnDestroy {

  constructor() { 
    console.log("===========AngularBasicsComponent created==============");

    
  }

  ngOnInit(): void {
    console.log("===========AngularBasicsComponent initialized==============");
    
  }

  ngOnDestroy(): void {
    console.log("===========AngularBasicsComponent destroyed==============");
    
  }

}
