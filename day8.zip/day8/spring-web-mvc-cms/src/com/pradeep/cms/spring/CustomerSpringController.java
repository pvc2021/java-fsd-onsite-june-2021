package com.pradeep.cms.spring;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.pradeep.cms.domain.Customer;
import com.pradeep.cms.service.CustomerService;

@Controller
//@Component  //default id customerMainApp
public class CustomerSpringController {

	@Qualifier("mapCustomerServiceImpl")
	@Autowired
//dependency	
	private CustomerService cs;

	public CustomerSpringController() {
		System.out.println("==========CustomerSpringController created=========");
	}
    @RequestMapping("/getallcustomers")
	public String getAllCustomers(ModelMap map) {
		map.addAttribute("customers", cs.findAllCustomers()); //model name
    	
    	return "customerList";  //view name
	}
	
	
}
