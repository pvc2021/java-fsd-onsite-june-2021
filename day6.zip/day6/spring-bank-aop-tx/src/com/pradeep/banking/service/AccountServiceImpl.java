package com.pradeep.banking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pradeep.banking.dao.AccountDao;
import com.pradeep.banking.model.Account;


@Transactional
@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	private AccountDao accountDao;
	

	public AccountServiceImpl() {
		System.out.println("AccountService default constructor created.....");
	}

	@Override
	public boolean addAccount(Account account) {
		// TODO Auto-generated method stub
		return accountDao.addAccount(account);
	}

	@Override
	public boolean deleteAccount(int accno) {

		return accountDao.deleteAccount(accno);
	}

	@Override
	public boolean updateAccount(Account account) {

		return accountDao.updateAccount(account);
		
	
	}

	@Transactional(readOnly=true)
	@Override
	public Account getAccount(int accno) {
		// TODO Auto-generated method stub
		return accountDao.getAccount(accno);

	}


	@Transactional(readOnly=true,timeout=6)
	@Override
	public List<Account> getAllAccounts() {
		
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// TODO Auto-generated method stub
		return accountDao.getAllAccounts();
	}

	@Override
	public boolean withdraw(int accno, double amount) {
		
	return accountDao.withdraw(accno, amount);
	
	}

	@Override
	public boolean deposit(int accno, double amount) {
		return accountDao.deposit(accno, amount);
	}

	
	
	
	@Override
	public boolean fundTransfer(int source, int destination, double amount) {
		
		System.out.println("In service  :"+source+"   "+destination);
		accountDao.withdraw(source, amount);
		
		int a=100/0;
		
		accountDao.deposit(destination, amount);
			
		return true;
	}

}
