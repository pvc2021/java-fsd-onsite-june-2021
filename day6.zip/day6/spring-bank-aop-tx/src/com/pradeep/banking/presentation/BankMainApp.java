package com.pradeep.banking.presentation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;

import com.pradeep.banking.model.Account;
import com.pradeep.banking.service.AccountService;

@Controller
public class BankMainApp {

	@Autowired
	private AccountService as;

	void addAccount(Account account) {

	}

	void updateAccount(Account account) {

	}

	void deleteAccount(int accno) {

	}

	void showAccount(int accno) {

	}

	void showAllAccounts() {
		System.out.println("All Accounts \n=================================");
		
		for(Account a:as.getAllAccounts())
			System.out.println(a);
					
	}

	
	
	void transferFund(int source,int destination,double amount) {
		
		if(as.fundTransfer(source, destination, amount))
			System.out.println("INR  "+amount+" is debited from Accno ["+source+"] and credited in Accno :"+destination+"");
		else
			System.out.println("Problem in trnasfering the fund");
	}
	
	public static void main(String[] args) {

	
	//Create a container	
	ClassPathXmlApplicationContext c=new ClassPathXmlApplicationContext("beans-tx.xml");
	System.out.println("Container created....");
	
  //make a request to container for BankMainApp Bean
	
		
	BankMainApp bma=c.getBean(BankMainApp.class);
	System.out.println("Got the BankMain App Bean");
	
	
	bma.showAllAccounts();
		
	bma.transferFund(101, 102, 10000.00);
		
	bma.showAllAccounts();
		
		
		
		
	}

}
