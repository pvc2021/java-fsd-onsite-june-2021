package com.pradeep.banking.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.pradeep.banking.data.AccountMap;
import com.pradeep.banking.model.Account;

@Repository
public class MapAccountDaoImpl implements AccountDao{

	@Override
	public boolean addAccount(Account account) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteAccount(int accno) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateAccount(Account account) {
		
		
		return false;
	}

	@Override
	public boolean withdraw(int accno, double amount) {
		
		
		System.out.println("In Dao deposit :"+accno+"    "+amount);
		
		Account account=null;
		
		if(AccountMap.INSTANCE.getMap().containsKey(accno))
		{
		   account=AccountMap.INSTANCE.getMap().get(accno);
		   account.setBalance(account.getBalance()-amount);
		   AccountMap.INSTANCE.getMap().put(accno, account);
		   
		   System.out.println("Withdraw success");
		   
		return true;
		}
		
		return false;
	}

	@Override
	public boolean deposit(int accno, double amount) {
		
		Account account=null;
		
		System.out.println("In Dao deposit :"+accno+"    "+amount);
		
		
		if(AccountMap.INSTANCE.getMap().containsKey(accno))
		{
		   account=AccountMap.INSTANCE.getMap().get(accno);
		   account.setBalance(account.getBalance()+amount);
		   AccountMap.INSTANCE.getMap().put(accno, account);
		   System.out.println("Deposit success");  
		   
	   	return true;
		}
		
		return false;
	}


	@Override
	public Account getAccount(int accno) {
		// TODO Auto-generated method stub
		return AccountMap.INSTANCE.getMap().get(accno);
	}

	@Override
	public List<Account> getAllAccounts() {
		// TODO Auto-generated method stub
		return new ArrayList<Account>(AccountMap.INSTANCE.getMap().values());
	}

}
