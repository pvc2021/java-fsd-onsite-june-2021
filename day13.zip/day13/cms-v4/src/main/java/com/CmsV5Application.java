package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class CmsV5Application {

	public static void main(String[] args) {
		SpringApplication.run(CmsV5Application.class, args);
	}

}
