import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'orderBy'
})
export class OrderByPipe implements PipeTransform {

  transform(array: any[],field='id',descending=false): any[] {
    
     var fieldtype=typeof(array[0][field])

     console.log("Field Type "+fieldtype);

     if(fieldtype=='number')
        array.sort((e1,e2)=>e1[field]-e2[field]);
     else if(fieldtype=='string')
        array.sort((e1,e2)=>e1[field].localeCompare(e2[field]));
     else  if(fieldtype=='object')
        array.sort((e1,e2)=>e1[field].getTime()-e2[field].getTime());
             
    if(descending)
    array.reverse();

    return array;

  }

}
