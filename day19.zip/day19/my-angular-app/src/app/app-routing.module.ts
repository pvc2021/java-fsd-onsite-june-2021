import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AlbumsComponent } from './albums/albums.component';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { CaseStudyComponent } from './case-study/case-study.component';
import { CommentsComponent } from './comments/comments.component';
import { CustomersComponent } from './customers/customers.component';
import { HomeComponent } from './home/home.component';
import { PhotosComponent } from './photos/photos.component';
import { PostsComponent } from './posts/posts.component';
import { TechnologiesComponent } from './technologies/technologies.component';
import { TodosComponent } from './todos/todos.component';
import { UsersListComponent } from './users-list/users-list.component';
import { UsersTableComponent } from './users-table/users-table.component';
import { UsersComponent } from './users/users.component';

const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'basics',component:AngularBasicsComponent},
  {path:'pipes',component:AngularPipesComponent},
  {path:'technologies',component:TechnologiesComponent},
  {path:'customers',component:CustomersComponent},
  
  {path:'casestudy',component:CaseStudyComponent,
   children:[

    {path:'users',component:UsersComponent,
    
     children:[
      {path:'list',component:UsersListComponent},
      {path:'table',component:UsersTableComponent}
     ]
   },
     {path:'users/:userId',component:UsersComponent},
     {path:'posts',component:PostsComponent},
    {path:'todos',component:TodosComponent},
    {path:'comments',component:CommentsComponent},
    {path:'photos',component:PhotosComponent},
    {path:'albums',component:AlbumsComponent}
  ]
},

  {path:'**',redirectTo:'home'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
