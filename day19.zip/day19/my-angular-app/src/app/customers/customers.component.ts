import { Component, OnInit } from '@angular/core';
import { CustomersService } from '../services/customers-service.service';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {

  title="Angular Integration with Spring Boot BAckend API";

  customers:any;
  customer:any;
  message="";


  add=false;
  update=false;



  constructor(private cs:CustomersService) { 
    console.log("===========CustomersComponent created==============");
    console.log(this.customers);
    

    
  }

  ngOnInit(): void {
    this.getAllCustomers();
    console.log(this.customers);

    console.log("===========CustomersComponent initialized==============");
   
  }

  ngOnDestroy(): void {
    console.log("===========CustomersComponent destroyed==============");
    
  }


  newCustomer(){
    this.add=false;
    this.update=true;
    
    this.customer={"customerId":0,"name":"","pan":"","mobile":"","address":"","dob":""};

  }


  getAllCustomers(){
    this.cs.getAllCustomers()
           .subscribe(response=>{this.customers=response;
          console.log("Success "+response);
                    
          },error=>this.message=error);
  }



  getCustomerById(customerId:number){
    this.add=true;
    this.update=false;

    this.cs.getCustomerById(customerId)
           .subscribe(response=>this.customer=response,error=>this.message=error);
  }


 deleteCustomerById(customerId:number){
    this.cs.deleteCustomerById(customerId)
           .subscribe(response=>this.customers=response,error=>this.message=error);
  }
  
  updateCustomerById(customerId:number){
    this.cs.updateCustomerById(customerId,this.customer)
           .subscribe(response=>this.customers=response,error=>this.message=error);

           this.customer=null;

  }
 
  
  addCustomer(){
    this.cs.addCustomer(this.customer)
           .subscribe(response=>this.customers=response,error=>this.message=error);
           this.customer=null;
           
  }
 
}
