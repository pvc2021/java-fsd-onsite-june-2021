package com.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SpringController {

	public SpringController() {
	System.out.println("========Spring Controller created==========");
	}
	
	
	@GetMapping("/")
	public String index() {
		return "Hi all,Welcome to Spring Boot application";
	}
	
	@GetMapping("/hello")
	public String hello() {
		return "Hello all,Welcome to Spring Boot application";
	}
	
	@GetMapping("/welcome")
	public String welcome() {
		return "Welcome to Spring Boot application";
	}
	
	
	@GetMapping("/error")
	public String error() {
		return "We are facing some issue Sorry for inconvinence";
	}
	
}
